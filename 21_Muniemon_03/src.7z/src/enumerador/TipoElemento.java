package enumerador;
public enum TipoElemento {
	AGUA,FUEGO,PLANTA
}